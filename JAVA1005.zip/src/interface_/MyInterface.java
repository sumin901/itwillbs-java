package interface_;

public interface MyInterface {
	void syso();
}
