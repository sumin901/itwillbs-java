package class_;

public class StudentTest {

	public static void main(String[] args) {
		Student1 studentYoon = new Student1();
		studentYoon.studentName = "윤수민";
		
		System.out.println(studentYoon.studentName);
		System.out.println(studentYoon.getStudentName());

	}

}
