

public class Ex {
	public static void main(String[] args) {
		String ineq; String eq; int n; int m;
		int answer = 0;
		ineq = "<";
		eq = "=";
		n = 20;
		m = 50;
				
		if (ineq.equals(">") && eq.equals("=")) {
            answer = (n>=m) ? 1 : 0 ;
        }
        else if (ineq == ">" && eq == "!") {
            answer = (n>m) ? 1 : 0 ;
        }
        else if (ineq == "<" && eq == "=") {
            answer = (n<=m) ? 1 : 0 ;
        }
        else if (ineq == "<" && eq == "!") {
            answer = (n<m) ? 1 : 0 ;
        }
	    
		System.out.println(answer);
		
	}
}