
public class Ex {

	public static void main(String[] args) {
		/*
		 * 자동완성(Content Assist) 단축키  : Ctrl + Spacear
		 */
		System.out.println("Hello, Java");
		System.out.println("한영광");
		System.out.println("아이티윌 부산 교육센터");
	}

}
